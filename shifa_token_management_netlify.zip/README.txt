SHIFA AL-KHOBAR MEDICAL CENTER — TOKEN MANAGEMENT SYSTEM

FILES
- index.html: the web app

NETLIFY DEPLOYMENT
1. Before using the app, open index.html in a text editor.
2. Find the firebaseConfig object in the script near the end of the file.
3. Replace all YOUR_... placeholder values with the web-app config from your Firebase project.
4. In Firebase Console, create/enable Realtime Database and set appropriate security rules.
5. Zip the folder contents (index.html and this README) and upload the ZIP to Netlify's manual deploy page, or drag the unzipped folder into Netlify Drop.

IMPORTANT SECURITY NOTES
- The supplied Firebase configuration is only a placeholder. The app will show a setup warning and will not register patient records until configured.
- Firebase web config values are not database access protection. Configure Firebase Authentication and restrictive Realtime Database rules before storing real patient information.
- This prototype stores patient names and file/ID numbers in the database. Confirm your medical center's privacy/security requirements before production use.
- The app uses a single shared state object. Simultaneous edits from multiple computers can overwrite each other; for production use, use authenticated per-record transactions or a server-side design.
- Browser printing opens a popup; allow popups for the site.
